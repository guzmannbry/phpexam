<?php
	include('db.php');
	$message = '';
	$lname = '';
	$fname = '';
	$address = '';
	$age = '';
	$gender = '';
	$role = '';
	//check if button submit is clicked
	if(isset($_POST['submit']))
	{
		$lname = trim($_POST['lname']);
		$fname = trim($_POST['fname']);
		$address = trim($_POST['address']);
		$age = trim($_POST['age']);
		$gender = trim($_POST['gender']);
		$role = trim($_POST['role']);
		if($lname != ''or $fname != '' or $address!=''or $age !='' or $gender='' or $role ='')
		{
			notes_add($lname, $fname,$address,$age,$gender,$role);
			$message = '<b class="text-info">Note has been successfully added.</b>';
			$lname = '';
			$fname = '';
			$address = '';
			$age = '';
			$gender = '';
			$role = '';
		}
		else
		{
			$message = '<b class="text-error">Please input title or notes.</b>';
		}
	}
?>

<html>
<head>
	<title>Notes Manager</title>
	<link href="bootstrap/css/bootstrap.css" type="text/css" rel="stylesheet" />
	<script src="bootstrap/js/jquery.js"></script>
	<script src="bootstrap/js/bootstrap.js"></script>
</head>
<body>
	<div class="container">
	
		<?php include('header.php'); ?>
		
		<h4>Add New Note</h4>
		<hr/>
		
		<form method="post">
			<div class="form-group">
				<label>Lastname:</label>
				<input class="form-control" type="text" name="lname" value="<?php echo htmlentities($lname); ?>" /></label>
			</div>
			<div class="form-group">
				<label>Firstname:</label>
				<input class="form-control" type="text" name="fname" value="<?php echo htmlentities($lname); ?>" /></label>
			</div>
			<div class="form-group">
				<label>Address:</label>
				<input class="form-control" type="text" name="address" value="<?php echo htmlentities($address); ?>" /></label>
			</div>
			<div class="form-group">
				<label>Age:</label>
				<input class="form-control" type="text" name="age" value="<?php echo htmlentities($age); ?>" /></label>
			</div>
			<div class="form-group">
				<label>Gender:</label>
				<input class="form-control" type="text" name="gender" value="<?php echo htmlentities($gender); ?>" /></label>
			</div>
			<div class="form-group">
				<label>Role:</label>
				<input class="form-control" type="text" name="role" value="<?php echo htmlentities($role); ?>" /></label>
			</div>
			
			<button class="btn" type="submit" name="submit"><i class="glyphicon glyphicon-floppy-disk"> </i> Save</button>
		</form>
		<?php echo $message; ?>
		
	</div>
</body>
</html>