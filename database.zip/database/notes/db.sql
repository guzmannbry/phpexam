

CREATE DATABASE `db_emp`;
USE `db_emp`;

CREATE TABLE IF NOT EXISTS `emp` (   
	`id` int(50) NOT NULL AUTO_INCREMENT,   
	`lname` varchar(100) NOT NULL,   
	`fname` varchar(300) NOT NULL,
	`address` varchar(300) NOT NULL, 
	`age` varchar(3) NOT NULL, 
	`gender` varchar(10) NOT NULL,
	`role` varchar(300) NOT NULL,     
	PRIMARY KEY (`id`) 
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3;

