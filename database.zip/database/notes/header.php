
<div class="page-header">
	<h1>
		<i class="glyphicon glyphicon-edit"></i> 
		Employee List
		<small class="pull-right">
			<a href="notes-add.php"><i class="glyphicon glyphicon-plus"> </i> Add Note</a> 
			<span>&nbsp; &nbsp;</span>
			<a href="notes-list.php"><i class="glyphicon glyphicon-th-list"> </i> View Notes</a>
			<span>&nbsp; &nbsp;</span>
			<a href="notes-search.php"><i class="glyphicon glyphicon-search"> </i> Search</a>
		</small> 
	</h1>
</div>
