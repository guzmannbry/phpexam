<?php
	include('db.php');
	
	$q = '';
	if(isset($_GET['q']))
	{
		$q = trim($_GET['q']);
	}
	if($q == '')
		$notes = notes_list();
	else
		$notes = notes_search($q);
?>

<html>
<head>
	<title>Notes Manager</title>
	<link href="bootstrap/css/bootstrap.css" type="text/css" rel="stylesheet" />
	<script src="bootstrap/js/jquery.js"></script>
	<script src="bootstrap/js/bootstrap.js"></script>
</head>
<body>
	<div class="container">
		
		<?php include('header.php'); ?>
		
		<h4>
			Search Notes
				<div class="pull-right">
				<form method="get" class="form-inline">
					<div class="input-group">
						<input type="text" name="q" value="<?php echo htmlentities($q); ?>" class="form-control input-small" placeholder="Search for...">
					  <span class="input-group-btn">
						<button class="btn btn-default btn-large" type="submit"> Go</button>
					  </span>					  
					</div><!-- /input-group -->					
				<form>
			</div>
		</h4>
		<hr/>
	
		<?php if(count($notes) > 0): ?>	
		<table border="0" class="table table-striped table-condensed table-bordered">
			<thead>
				<tr>
					<th width="60"></th>
					<th width="60">ID</th>
					<th width="200">Employee Name</th>
					<th width="200">Address</th>
					<th width="60">Age</th>
					<th width="60">Gender</th>
					<th width="60">Role</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($notes as $n): ?>
				<tr>
					<td>
						<a href="notes-edit.php?id=<?php echo htmlentities($n['id']); ?>">
							<i class="glyphicon glyphicon-pencil"> </i>
						</a>
						<a href="notes-delete.php?id=<?php echo htmlentities($n['id']); ?>" onclick="return confirm('Are you sure?');">
							<i class="glyphicon glyphicon-trash"> </i>
						</a>
					</td>
					<td><?php echo htmlentities($n['id']); ?></td>
					<td><?php echo htmlentities($n['lname']); ?></td>
					<td><?php echo htmlentities($n['fname']); ?></td>
					<td><?php echo htmlentities($n['address']); ?></td>
					<td><?php echo htmlentities($n['age']); ?></td>
					<td><?php echo htmlentities($n['gender']); ?></td>
					<td><?php echo htmlentities($n['role']); ?></td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<div class="text-info"><b><?php echo count($notes); ?></b> matching record(s) found.
		<?php else: ?>
		<div class="text-warning">No matching entries found.</div>
		<?php endif; ?>
		
	</div>
</body>
</html>