<?php
	include('db.php');
	$message = '';
	$title = '';
	
	if(!isset($_GET['id']))
	{
		//note id is not specified go back to notes-list page
		header('location: notes-list.php');
		exit();
	}
	
	$id = intval($_GET['id']);
	
	//check if button submit is clicked
	if(isset($_POST['submit']))
	{
		$title = trim($_POST['title']);
		$text = trim($_POST['text']);
		
		if($title != '' and $text != '')
		{
			notes_update($id, $title, $text);
			$message = '<b class="text-info">Note has been successfully updated.</b>';
		}
		else
		{
			$message = '<b class="text-error">Please input title or notes.</b>';
		}
	}
	else 
	{
		//if not submitted we retrieve the data from the database
		$note = notes_find($id);
		if($note)
		{
			$title = $note['title'];
			$text = $note['text']; 
		}
		else
		{
			$message = '<b class="text-error">The specified note record cannot be found.</b>';
		}
	}
?>

<html>
<head>
	<title>Notes Manager</title>
	<link href="bootstrap/css/bootstrap.css" type="text/css" rel="stylesheet" />
	<script src="bootstrap/js/jquery.js"></script>
	<script src="bootstrap/js/bootstrap.js"></script>
</head>
<body>
	<div class="container">
			
		<?php include('header.php'); ?>
		
		<h4>Edit Notes</h4>
		<hr/>
		<form method="post">
			<div class="form-group">
				<label>Title:</label>
				<input class="form-control" type="text" name="title" value="<?php echo htmlentities($title); ?>" /></label>
			</div>
			<div class="form-group">
				<label>Details:</label>
				<textarea name="text" class="form-control" rows="5"><?php echo htmlentities($text); ?></textarea>
			</div>
			<br>
			<button class="btn" type="submit" name="submit"><i class="glyphicon glyphicon-floppy-disk"> </i> Save</button>
		</form>
		<?php echo $message; ?>
		
	</div>
</body>
</html>