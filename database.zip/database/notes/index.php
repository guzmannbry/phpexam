<?php 

	header('location: notes-list.php'); 
	exit();

?>