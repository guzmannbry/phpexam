<?php

	function db_notes()
	{
		$user = 'root';
		$pass = '';
		$db = null;
		try
		{
			$db = new PDO('mysql:host=localhost;dbname=db_notes;', $user, $pass);
			//$db->setAttribute(PDO_ATTR_ERRMODE, PDO_ERRMODE_EXCEPTION);
		}
		catch(PDOException $e)
		{
			echo 'Connection failed.';
		}		
		return $db;
	}

	function notes_add($lname, $fname,$address,$age,$gender,$role)
	{
		$db = db_notes();
		$sql = "insert into note(lname,fname,address,age,gender,role) values(?, ?)";
		$st = $db->prepare($sql);
		$st->execute(array($lname, $fname,$address,$age,$gender,$role));
		$db = null;
	}
	
	function notes_update($id,$lname, $fname,$address,$age,$gender,$role)
	{
		$db = db_notes();
		$sql = "update note set lname=? ,fname=?, address=?,age=?,gender=?,role=? where id=?";
		$st = $db->prepare($sql);
		$st->execute(array($lname, $fname,$address,$age,$gender,$role, $id));
		$db = null;
	}
	
	function notes_delete($id)
	{
		$db = db_notes();
		$sql = "delete from note where id=?";
		$st = $db->prepare($sql);
		$st->execute(array($id));
		$db = null;
	}
	
	function notes_list()
	{
		$db = db_notes();
		$sql = "select * from note order by 1 desc";
		$st = $db->prepare($sql);
		$st->execute();
		$rows = $st->fetchAll();
		$db = null;
		
		return $rows;
	}
	
	function notes_find($id)
	{
		$db = db_notes();
		$sql = "select * from note where id=?";
		$st = $db->prepare($sql);
		$st->execute(array($id));
		$row = $st->fetch();
		$db = null;
		
		return $row;
	}
	
	function notes_search($keyword)
	{
		$keyword = '%'. $keyword . '%'; //add wildcard for partial matching
		
		$db = db_notes();
		$sql = "select * from note where lname like ? or fname like ?";
		$st = $db->prepare($sql);
		$st->execute(array($keyword, $keyword));
		$rows = $st->fetchAll();
		$db = null;
		
		return $rows;
	}