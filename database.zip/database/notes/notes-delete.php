<?php
	include('db.php');
	$message = '';
	
	//we use $_GET because data input came from the URL
	if(isset($_GET['id']))
	{
		$id = trim($_GET['id']);
		$note = notes_find($id);
		if($note)
		{
			notes_delete($id);
			$message = '<b class="text-info">Selected note has been deleted.</b>';
		}
		else
		{
			$message = '<b class="text-error">The specified note cannot be found.</b>';
		}
	}
?>

<html>
<head>
	<title>Notes Manager</title>
	<link href="bootstrap/css/bootstrap.css" type="text/css" rel="stylesheet" />
	<script src="bootstrap/js/jquery.js"></script>
	<script src="bootstrap/js/bootstrap.js"></script>
</head>
<body>
	<div class="container">
	
		<?php include('header.php'); ?>
		
		<h4>Delete Notes</h4>
		<hr/>
		
		<p>
			<?php echo $message; ?>
		</p>
		<script>
			//go back to notes list page after 3 seconds.
			setTimeout(function(){ document.location = 'notes-list.php'; }, 2000);
		</script>
		
	</div>
</body>
</html>