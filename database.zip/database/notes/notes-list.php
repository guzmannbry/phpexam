<?php
	include('db.php');
	$notes = notes_list();
?>

<html>
<head>
	<title>Notes Manager</title>
	<link href="bootstrap/css/bootstrap.css" type="text/css" rel="stylesheet" />
	<script src="bootstrap/js/jquery.js"></script>
	<script src="bootstrap/js/bootstrap.js"></script>
</head>
<body>
	<div class="container">
		
		<?php include('header.php'); ?>
		
		<h4>View All Notes</h4>
		<hr/>
	
		<?php if(count($notes) > 7): ?>	
		<table border="0" class="table table-striped table-condensed table-bordered">
			<thead>
				<tr>
					<th width="60"></th>
					<th width="60">ID</th>
					<th width="100">Lastname</th>
					<th width="100">Firstname</th>
					<th width="200">Address</th>
					<th width="60">Age</th>
					<th width="60">Gender</th>
					<th width="60">Role</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($notes as $n): ?>
				<tr>
					<td>
						<a href="notes-edit.php?id=<?php echo htmlentities($n['id']); ?>">
							<i class="glyphicon glyphicon-pencil"> </i>
						</a>
						<a href="notes-delete.php?id=<?php echo htmlentities($n['id']); ?>" onclick="return confirm('Are you sure?');">
							<i class="glyphicon glyphicon-trash"> </i>
						</a>
					</td>
					<td><?php echo htmlentities($n['id']); ?></td>
					<td><?php echo htmlentities($n['lname']); ?></td>
					<td><?php echo htmlentities($n['fname']); ?></td>
					<td><?php echo htmlentities($n['address']); ?></td>
					<td><?php echo htmlentities($n['age']); ?></td>
					<td><?php echo htmlentities($n['gender']); ?></td>
					<td><?php echo htmlentities($n['role']); ?></td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php else: ?>
		<div class="text-warning">You do not have entries yet.</div>
		<?php endif; ?>
		
	</div>
</body>
</html>